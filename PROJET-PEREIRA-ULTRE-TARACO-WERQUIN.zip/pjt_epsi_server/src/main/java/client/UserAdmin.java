package client;

public class UserAdmin extends User {

	public UserAdmin(String username, int id) {
		super(username, id);
		// TODO Auto-generated constructor stub
	}
 }
